#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    m_bDrag = false;
    sound = new QSound(":/Res/鸡.wav",this);
    Timer = new QTimer(this);
    label = new QLabel(this);

    //参数一：字体 参数二：大小
    QFont font("Microsoft YaHei",15);
    //设置label背景颜色 ， 字体颜色
    label->setStyleSheet("background:transparent;color:rgb(0,0,0);");
    label->setFont(font);
    label->setGeometry(70,50,100,110);

    //去掉窗口边框
    this->setWindowFlags(Qt::FramelessWindowHint | windowFlags());
    //把窗口设置透明
    this->setAttribute(Qt::WA_TranslucentBackground);
    //设置窗口置顶
    this->setWindowFlags(Qt::WindowStaysOnTopHint | windowFlags());
    //限定窗口尺寸
    this->setFixedHeight(150);
    this->setFixedWidth(300);

    connect(Timer, SIGNAL(timeout()), this, SLOT(myTimerOut()));

    mSysTrayIcon = new QSystemTrayIcon(this);
    mSysTrayIcon->setIcon(QIcon(":/Res/CXK_3.ico"));
    mSysTrayIcon->setToolTip("CXK_3");
    connect(mSysTrayIcon,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason)));
    connect(mSysTrayIcon,&QSystemTrayIcon::messageClicked,[&](){
    this->show(); });

    //建立托盘操作的菜单
    createActions();
    createMenu();
    //在系统托盘显示此对象
    mSysTrayIcon->show();
}

void Widget::paintEvent(QPaintEvent *)
{
    QPainter Painter(this);
    Painter.begin(this);
    if (m_bDrag)
    {        
        Painter.drawPixmap(150, 0, QPixmap(":/Res/CXK_2.png"));
        Painter.drawPixmap(55, 70, QPixmap(":/Res/CXK.png"));
    }
    else
    {
        label->clear();
        Painter.drawPixmap(150, 0, QPixmap(":/Res/CXK_1.png"));
    }
}

// 鼠标按下事件
void Widget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
//        label->setText("讨厌！");
//        m_bDrag = true;
        m_bDrag1 = true;
        //获取数据初始位置
        mouseStartPoint = event->globalPos();
        //获取窗口初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();
        //触发一次paintEvent
        QWidget::update();
    }
}

void Widget::mouseDoubleClickEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        label->setText("你干嘛！");
        sound->play(":/Res/你干嘛.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
}

// 鼠标移动事件
void Widget::mouseMoveEvent(QMouseEvent *event)
{
    if (m_bDrag1)
    {
        //获得鼠标移动距离
        QPoint distance = event->globalPos() - mouseStartPoint;
        //改变窗口位置
        this->move(windowTopLeftPoint + distance);
    }
}

// 鼠标释放事件
void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
        m_bDrag1 = false;
        QWidget::update();
    }
}

//键盘按下事件
void Widget::keyPressEvent(QKeyEvent *event)
{
    qDebug()<<event->text();

    if (event->text() == "j" || event->text() == "J")       //鸡
    {
        label->setText("鸡！");
        sound->play(":/Res/鸡.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);

    }
    else if (event->text() == "n" || event->text() == "N")  //你
    {
        label->setText("你！");
        sound->play(":/Res/你.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == "t" || event->text() == "T")  //太
    {
        label->setText("太！");
        sound->play(":/Res/太.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == "m" || event->text() == "M")  //美
    {
        label->setText("美！");
        sound->play(":/Res/美.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == "\u0003")                     //唱
    {
        label->setText("唱！");
        sound->play(":/Res/唱.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == "\u0014")                     //跳
    {
        label->setText("跳！");
        sound->play(":/Res/跳.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == "\u0012")                     //rap
    {
        label->setText("rap！");
        sound->play(":/Res/rap.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == "\f")                         //篮球
    {
        label->setText("篮球！");
        sound->play(":/Res/篮球.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);
    }
    else if (event->text() == " ")                         //你干嘛
    {
        label->setText("你干嘛！");
        sound->play(":/Res/你干嘛.wav");
        m_bDrag = true;
        QWidget::update();
        Timer->stop();
        Timer->start(500);

    }
}


void Widget::on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason)
{
    switch(reason){
    case QSystemTrayIcon::Trigger:
        mSysTrayIcon->showMessage("练习时长两年半的个人练习生", "中分背带裤，我是ikun我最酷！",QSystemTrayIcon::Information, 1000);
        break;
    case QSystemTrayIcon::DoubleClick:
        this->show();
        break;
    default:
        break;
    }
}

void Widget::createActions()
{
    mShowMainAction = new QAction("展示", this);
    connect(mShowMainAction,SIGNAL(triggered()),this,SLOT(on_showMainAction()));

    mHideAppAction = new QAction("隐藏", this);
    connect(mHideAppAction,&QAction::triggered,[&](){this->hide();});

    mExitAppAction = new QAction("退出", this);
    connect(mExitAppAction,SIGNAL(triggered()), this, SLOT(on_exitAppAction()));
}

void Widget::createMenu()
{
    mMenu = new QMenu(this);
    mMenu->addAction(mShowMainAction);
    mMenu->addAction(mHideAppAction);
    mMenu->addAction(mExitAppAction);
    mSysTrayIcon->setContextMenu(mMenu);
}

void Widget::on_showMainAction()
{
    this->show();
}

void Widget::on_exitAppAction()
{
    exit(0);
}

void Widget::myTimerOut()
{
    m_bDrag = false;
    QWidget::update();
}

Widget::~Widget()
{
    delete ui;
}
