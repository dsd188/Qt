#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSystemTrayIcon>
#include <QAction>
#include <QMenu>
#include <QMouseEvent>
#include <QTextCharFormat>
#include <QPainter>
#include <QSound>
#include <QBitmap>
#include <QDebug>
#include <QKeyEvent>
#include <QTimer>
#include <QLabel>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);

    QSystemTrayIcon* mSysTrayIcon;
    QMenu *mMenu;
    QAction *mShowMainAction;
    QAction *mExitAppAction;
    QAction *mHideAppAction;
    void createActions();
    void createMenu();

    void paintEvent(QPaintEvent *);
    // 鼠标按下事件
    void mousePressEvent(QMouseEvent *event);
    // 鼠标移动事件
    void mouseMoveEvent(QMouseEvent *event);
    // 鼠标释放事件
    void mouseReleaseEvent(QMouseEvent *event);
    // 鼠标双击事件
    void mouseDoubleClickEvent(QMouseEvent *event);
    //键盘按下事件
    void keyPressEvent(QKeyEvent *event);
    ~Widget();
private slots:
    void on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason);
    void on_showMainAction();
    void on_exitAppAction();    
    void myTimerOut();
private:
    bool m_bDrag;
    bool m_bDrag1;
    QPoint mouseStartPoint;
    QPoint windowTopLeftPoint;
    Ui::Widget *ui;
    QSound *sound;
    QPoint p;
    QTimer *Timer;
    QLabel *label;
};

#endif // WIDGET_H
